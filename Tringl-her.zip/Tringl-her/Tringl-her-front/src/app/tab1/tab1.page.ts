import { LikeService } from './../like.service';
import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { DomSanitizer } from '@angular/platform-browser';


@Component({
    selector: 'app-tab1',
    templateUrl: 'tab1.page.html',
    styleUrls: ['tab1.page.scss']
})
export class Tab1Page implements OnInit {
    userId = 0;
    likedUsers = [];
    users = [];

    constructor(public userService: UserService, private likeService: LikeService, private sanitizer: DomSanitizer ) {
    }
    getSanitizedImg() {
      return this.sanitizer.bypassSecurityTrustUrl('data:Image/jpeg;base64,' + this.users[this.userId].photo);
    }
    ngOnInit() {
      this.loadUser();
    }

    async loadUser()  {

    try {
      const res = await this.userService.getUsers();
      this.users = res;
      console.log('users:', this.users);
      return res;
    }  catch (err) {
      console.log(err);
    }
  }

  async nextPerson() {
    // tslint:disable-next-line:no-unused-expression
    this.userId = this.userId + 1;
  }

  async like(user)  {
    this.likedUsers.push(this.users[this.userId]);
    console.log(this.likedUsers);
    this.nextPerson();
    this.likeService.users = this.likedUsers;
    localStorage.setItem('liked', JSON.stringify(this.likedUsers));
  }
}
