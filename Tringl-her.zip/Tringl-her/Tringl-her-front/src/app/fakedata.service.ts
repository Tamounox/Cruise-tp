import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FakedataService {
  users = [
    {
        id: 1,
        image: './../../assets/13.jpg',
        userName: 'igorette',
        userLastName: 'De igoratre',
      },
      {
        id: 2,
        image: './../../assets/14.jpg',
        userName: 'igorat',
        userLastName: 'De igorkun',
      }
  ];

  getData() {
    return this.users;
  }

}
