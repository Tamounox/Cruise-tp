import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(public http: HttpClient) {
  }

  getUsers(): Promise<any> {
    const cors = 'https://cors-anywhere.herokuapp.com/';
    const url = cors + 'http://ynovimaginecup.pythonanywhere.com/api/tringl-her';
    return this.http
      .get(url)
      .toPromise()
      .then(this.treating)
      .catch(this.treatingBad);
  }

  private treating(res: any) {
    const body = res;
    return body;
  }

  /**
   * la Methode retourne le message d'erreur ou l'erreur même
   *
   * @private
   * @param {*} error
   * @returns {Promise<any>}
   * @memberof ConsultantsService
   */
  private treatingBad(error: any): Promise<any> {
    console.error('An error occurred', error); // for development purposes only
    return Promise.reject(error.message || error);
  }


}
