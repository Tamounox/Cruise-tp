import { LikeService } from './../like.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab2',
  templateUrl: './tab2.page.html',
  styleUrls: ['./tab2.page.scss'],
})
export class Tab2Page implements OnInit {

  constructor(private likeService: LikeService) { }

  users = [];
  ngOnInit() {}
  ionViewDidEnter() {
    this.getLiked();
  }

  getLiked()  {
    this.users = JSON.parse(localStorage.getItem('liked'));
    console.log('coucou' , this.users);
  }


  // getUsers() {
  //   this.likeService.getUsers().subscribe(
  //     users => this.users = users
  //   );
  // }
}
